from django.apps import AppConfig


class JsonresOnlyConfig(AppConfig):
    name = 'jsonres_only'
